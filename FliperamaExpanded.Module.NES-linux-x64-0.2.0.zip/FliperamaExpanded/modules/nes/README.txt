Modulo FliperamaExpanded.Module.NES — FliperamaExpanded

Este é um módulo opcional do FliperamaExpanded (pacote linux-x64). Extraia o zip
dentro de Mods/ do Stardew Valley (a estrutura FliperamaExpanded/modules/nes/
será criada automaticamente). O host FliperamaExpanded deve estar instalado.

ROMs: coloque em Mods/FliperamaExpanded/roms/nes/. O arquivo de licença do
núcleo de emulação está na subpasta licenses/.
