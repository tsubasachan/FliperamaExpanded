Modulo FliperamaExpanded.Module.GBA — FliperamaExpanded

Este é um módulo opcional do FliperamaExpanded (pacote win-x64). Extraia o zip
dentro de Mods/ do Stardew Valley (a estrutura FliperamaExpanded/modules/gba/
será criada automaticamente). O host FliperamaExpanded deve estar instalado.

ROMs: coloque em Mods/FliperamaExpanded/roms/gba/. O arquivo de licença do
núcleo de emulação está na subpasta licenses/.
