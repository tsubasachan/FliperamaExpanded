Modulo FliperamaExpanded.Module.MegaDrive — FliperamaExpanded

Este é um módulo opcional do FliperamaExpanded. Extraia o zip dentro de Mods/
do Stardew Valley (a estrutura FliperamaExpanded/modules/megadrive/ será criada
automaticamente). O host FliperamaExpanded deve estar instalado.

ROMs: coloque em Mods/FliperamaExpanded/roms/megadrive/. O arquivo de licença do
núcleo de emulação está na subpasta licenses/.
