# Third-Party Notices — FliperamaExpanded Mega Drive Module

This module integrates the native **Genesis Plus GX** emulator core via Libretro C API bindings.

## Genesis Plus GX
- **Project:** [libretro/Genesis-Plus-GX](https://github.com/libretro/Genesis-Plus-GX)
- **License:** Genesis Plus GX Non-Commercial License (see `licenses/GenesisPlusGX-LICENSE.md`)
- **Copyright:** (C) 1998-2003 Charles Mac Donald, 2007-2023 Eke-Eke and the Libretro Team.
