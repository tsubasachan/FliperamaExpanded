Saves automaticos do console gba (nao mexer).
