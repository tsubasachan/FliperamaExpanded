PASTA DE SAVES (automatica)

O mod salva aqui o progresso e os estados dos jogos (F5 = salvar, F8 = carregar).
Nao precisa mexer — os arquivos sao criados automaticamente.
