Saves automaticos do console gameboy (nao mexer).
