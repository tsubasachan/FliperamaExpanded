Saves automaticos do console nes (nao mexer).
