Saves automaticos do console snes (nao mexer).
