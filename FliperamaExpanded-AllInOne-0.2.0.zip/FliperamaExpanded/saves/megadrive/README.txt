Saves automaticos do console megadrive (nao mexer).
