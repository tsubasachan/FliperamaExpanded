# FliperamaExpanded

Expanda o fliperama do Stardrop Saloon com uma economia completa de fichas, tickets de fidelidade e roleta de prêmios — com o **Journey of the Prairie King** integrado à jogatina paga, HUD de saldo em tempo real e o Gus cuidando das máquinas como um verdadeiro dono de bar.

## O que o mod faz

- **Arcade Station** — menu em tela cheia para escolher e jogar no fliperama, com abas, filtros, capas de jogos e remapeamento de controles por teclado e gamepad.
- **Fichas do Saloon** — moeda própria do fliperama, comprada no balcão do Gus (100 fichas por 1.000 ouros, configurável). Entrar numa partida custa fichas, e cada hora de jogo cobra a tarifa pelo relógio natural do Stardew Valley.
- **Journey of the Prairie King pago** — o clássico do Saloon agora respeita a economia do fliperama: cobrança de entrada, tarifa por hora, contador anti-inatividade e despejo na hora de fechar.
- **HUD de sessão** — relógio do jogo, saldo de fichas e progresso do ticket de fidelidade (🎟️ Xh Ym / 5h) durante toda a partida.
- **Tickets do Fliperama** — jogue 5 horas contínuas (configurável) dentro do mesmo jogo e ganhe 1 Ticket do Fliperama. Metas semanais bônus: jogar nos 7 dias, maratona diária de 5h e mestre da variedade.
- **Roleta de Prêmios do Saloon** — troque tickets por prêmios no balcão do Gus ou pela aba da roleta: Fragmento Prismático, Taco de Peixe, Bolo Rosa, Diamante, Pizza do Gus, Espresso Triplo, Salada, Pão Caseiro e fichas bônus.
- **Máquinas vivas** — o Gus liga as máquinas uma a uma a partir das 12:00 (com som e faíscas) e desliga tudo às 23:00, expulsando quem ainda estiver jogando. NPCs gamers (Abigail, Sam, Sebastian e Shane) ocupam as máquinas em dias de chuva e sextas à noite.
- **Exclusividade** — uma pessoa por máquina de cada vez, inclusive no multiplayer.

## Requisitos

- Stardew Valley **1.6+**
- SMAPI **4.0+**

## Instalação

1. Extraia o zip **mantendo a pasta `FliperamaExpanded/`** dentro de `Mods/`. Dica para Linux: seu gerenciador de arquivos costuma criar uma pasta com o nome do zip ao extrair — se aparecer `Mods/FliperamaExpanded/FliperamaExpanded/`, você extraiu no lugar errado: mova a pasta `FliperamaExpanded` de dentro para `Mods/`.
2. Rode o jogo pelo SMAPI. Na primeira execução o mod cria as pastas de dados e o `config.json` padrão.
3. Conteúdo adicional de jogos (opcional) é instalado separadamente — veja o repositório do autor.

## Configuração

O `config.json` é criado na primeira execução com os padrões abaixo:

| Opção | Padrão | Descrição |
| --- | --- | --- |
| `TokenBundleAmount` / `TokenBundlePrice` | `100` / `1000` | Pacote de fichas comprado no balcão do Gus |
| `SessionStartTokenCost` | `10` | Fichas cobradas ao iniciar a partida |
| `HourlyTokenCost` | `10` | Fichas por hora do relógio do jogo |
| `AdvanceGameTimeDuringPlay` | `true` | Avança o relógio do jogo durante a partida |
| `HoursPerPrizeTicket` | `5` | Horas de jogo para ganhar 1 Ticket do Fliperama |
| `Key*` | — | Mapeamento de teclado (também remapeável na aba Controles do fliperama) |

## Controles

- **F1** — menu de pausa (continuar, salvar, carregar, reiniciar, sair)
- **F5 / F8** — salvamento / carregamento rápido
- **Espaço ou gatilho direito do gamepad** — avanço rápido (turbo)
- As máquinas começam desligadas e são ativadas pelo Gus a partir das **12:00**; o Saloon fecha às **23:00**
- Saldo insuficiente de fichas encerra a partida automaticamente (com o progresso preservado)

## Traduções

Português (Brasil), Inglês e Espanhol — o idioma é detectado automaticamente das configurações do jogo.

## Licenças

Este mod é distribuído sob a licença MIT. A biblioteca de integração **0Harmony** é distribuída sob a licença MIT (© 2017 Andreas Pardeike e colaboradores). Núcleos de conteúdo adicional distribuídos separadamente possuem suas próprias licenças, listadas em seus respectivos pacotes.

## Suporte

Testado no Linux (Stardew Valley 1.6.15, SMAPI 4.5.2) e Windows (x64). Se encontrar problemas, reporte com o conteúdo do `SMAPI-crash.txt` (se houver) e o log do SMAPI.