Coloque aqui seus jogos .sfc ou .smc (apenas ROMs homebrew ou backups proprios).
