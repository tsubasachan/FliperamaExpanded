PASTA DE JOGOS (ROMs)

Coloque seus jogos nas subpastas dos consoles:

  roms/gba/        -> jogos .gba
  roms/snes/       -> jogos .sfc ou .smc
  roms/nes/        -> jogos .nes
  roms/megadrive/  -> jogos .md, .gen ou .smd
  roms/gameboy/    -> jogos .gb ou .gbc

Use apenas ROMs homebrew (licença livre) ou backups dos seus proprios
cartuchos. Este mod nao distribui nem hospeda ROMs comerciais.
