Capas dos jogos geradas automaticamente pelo mod (nao mexer).
