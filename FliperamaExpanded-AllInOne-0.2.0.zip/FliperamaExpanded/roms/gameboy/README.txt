Coloque aqui seus jogos .gb ou .gbc (apenas ROMs homebrew ou backups proprios).
