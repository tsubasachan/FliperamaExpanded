Coloque aqui seus jogos .nes (apenas ROMs homebrew ou backups proprios).
