Modulo FliperamaExpanded.Module.GameBoy — FliperamaExpanded

Este é um módulo opcional do FliperamaExpanded. Extraia o zip dentro de Mods/
do Stardew Valley (a estrutura FliperamaExpanded/modules/gameboy/ será criada
automaticamente). O host FliperamaExpanded deve estar instalado.

ROMs: coloque em Mods/FliperamaExpanded/roms/gameboy/. O arquivo de licença do
núcleo de emulação está na subpasta licenses/.
