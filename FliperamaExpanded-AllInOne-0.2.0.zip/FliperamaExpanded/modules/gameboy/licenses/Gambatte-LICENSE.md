# Gambatte License (GPL-2.0)

Gambatte is an open-source Game Boy / Game Boy Color emulator licensed under the GNU General Public License version 2.

Copyright (C) 2007-2014 Sinamas <sinamas@users.sourceforge.net>
Copyright (C) 2014-2023 The Libretro Team
