# Third-Party Notices — FliperamaExpanded Game Boy / Color Module

This module integrates the native **Gambatte** emulator core via Libretro C API bindings.

## Gambatte
- **Project:** [libretro/gambatte-libretro](https://github.com/libretro/gambatte-libretro)
- **License:** GNU General Public License v2 (see `licenses/Gambatte-LICENSE.md`)
- **Copyright:** (C) 2007-2023 Sinamas and the Libretro Team.
