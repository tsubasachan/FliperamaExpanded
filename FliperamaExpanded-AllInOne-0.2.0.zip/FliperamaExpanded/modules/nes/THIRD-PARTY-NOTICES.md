# Third-Party Notices — FliperamaExpanded NES Module

This module integrates the native **FCEUmm** emulator core via Libretro C API bindings.

## FCEUmm
- **Project:** [libretro/libretro-fceumm](https://github.com/libretro/libretro-fceumm)
- **License:** GNU General Public License v2 (see `licenses/FCEUmm-LICENSE.md`)
- **Copyright:** (C) 1998-2023 Bero, Xodn, CaH4e3, Zeromus, and the Libretro Team.
