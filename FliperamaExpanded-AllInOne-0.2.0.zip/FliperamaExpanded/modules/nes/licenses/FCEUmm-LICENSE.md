# FCEUmm License (GPL-2.0)

FCEUmm (FCE Ultra mappers modified) is licensed under the GNU General Public License version 2.

Copyright (C) 1998-2004 Bero, Xodn组织, CaH4e3, Zeromus, and the FCE Ultra team.
Copyright (C) 2010-2023 The Libretro Team.
