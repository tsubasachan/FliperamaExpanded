# Third-party notices

## mGBA (libretro core)

FliperamaExpanded bundles the native `mgba_libretro` library from [mGBA](https://mgba.io) / [libretro-mgba](https://github.com/libretro/mgba).

Copyright (c) 2013-2026 Jeffrey Pfau and mGBA contributors.
Distributed under the Mozilla Public License Version 2.0.
A copy of the MPL 2.0 license is included in `licenses/mGBA-LICENSE.md`.
