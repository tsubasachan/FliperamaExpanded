# Third-Party Notices — FliperamaExpanded SNES Module

This module integrates the native **Snes9x** emulator core via Libretro C API bindings.

## Snes9x
- **Project:** [snes9x/snes9x](https://github.com/snes9xgit/snes9x)
- **License:** Snes9x Non-Commercial License (see `licenses/Snes9x-LICENSE.md`)
- **Copyright:** (c) 1996 - 2018 Gary Henderson, Jerremy Koot, BearOso, OV2 and contributors.
