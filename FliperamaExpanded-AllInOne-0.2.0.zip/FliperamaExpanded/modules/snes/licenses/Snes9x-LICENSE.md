# Snes9x License

```
/*
 * Snes9x - Portable Super Nintendo Entertainment System (TM) emulator.
 *
 * (c) Copyright 1996 - 2002  Gary Henderson (gary.henderson@ntlworld.com)
 *                            Jerremy Koot (jkoot@snes9x.com)
 *
 * (c) Copyright 2001 - 2004  Amit Patel
 * (c) Copyright 2001 - 2002  caitsith2
 * (c) Copyright 2002 - 2004  Victor Moya (victormoya@users.sourceforge.net)
 * (c) Copyright 2002 - 2003  coder
 * (c) Copyright 2005         zones (zones@snes9x.com)
 * (c) Copyright 2006 - 2007  nitsuja
 * (c) Copyright 2009 - 2018  BearOso, OV2
 *
 * Permission to use, copy, modify and/or distribute Snes9x in both binary
 * and source form, for non-commercial purposes, is hereby granted without fee,
 * providing that this license information and copyright notice appear with
 * all copies and any derived work.
 *
 * This software is provided 'as-is', without any express or implied
 * warranty. In no event will the authors be held liable for any damages
 * arising from the use of this software.
 *
 * Snes9x is freeware for PERSONAL USE only. Commercial users should
 * seek permission of the copyright holders first. Commercial use includes,
 * but is not limited to, charging money for Snes9x or distributing Snes9x
 * with commercial products.
 */
```
