Opcional: BIOS dumpeada do seu proprio hardware. Sem ela o emulador funciona em modo HLE.
