PASTA DE BIOS (opcional)

Os emuladores funcionam sem BIOS (modo HLE). Se tiver a BIOS dumpeada
do seu proprio hardware, coloque na subpasta do console
(ex.: bios/gba/gba_bios.bin).
